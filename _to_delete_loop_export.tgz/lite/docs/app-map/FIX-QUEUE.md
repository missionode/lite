# Fix queue derived from the flow atlas

## Completed — Mantra no longer drops suddenly

- End of each chakra: the mantra used a 2 s fade (half of the 4 s post-mantra gap). It now leaves over a 12 s window (6 s fade + reverb tail) that begins inside the chant time, so the chakra's total time is unchanged (`transitions.chakraMantraExit`, 0 in fast-test).
- Pause: the audio clock was suspended instantly (hard cut). The whole mix now fades out over 0.8 s before suspending and fades back in over 1.2 s on resume (new `pauseFader` after the master limiter).
- Skip: mantra fade raised from 1 s to about 3 s. Session stop keeps its 8 s fade.

## Completed — Clear, translation-friendly assessment questions

- All 28 chakra questions, their 56 answers, the value prompt and the 8 value cards are rewritten in plain, short English with the same meaning, IDs and weights (no idioms; Google Translate friendly). Question bank `?v=1.3`.

## Completed — Service-fit dot, answer order and card repetition

- Dot rounds now always compare one pleasure-leaning card with one cautious card (all 12 pairs of 4 × 3; the neutral Commitment card is not asked). Dot = green when ≥ 75% of the client's picks lean to pleasure, red when ≥ 75% lean to caution, else orange; Equal/Skip never count; at least 8 picks from 3 cards needed. Red was impossible before. Simulated: random answers 7% green / 2% red; clients who lean one way 8 times in 10 get that colour ~80% of the time (was 42% green, 0% red).
- No value card appears in two rounds in a row, and each card moves between left and right. Each cautious card still appears 4 times and each pleasure card 3 times, the minimum for 12 informative rounds.
- Chakra questions show the healthier answer on the right for 13 of 28 questions (stable per question), so "always tap left" no longer works. Bank content version 2026-10-01.1 (older saved sessions restart).

## Completed — Spelling proofread (all languages)

- Dictionary pass (hunspell en/ru/hi/ml + LibreOffice ta) plus a line-by-line native proofread of all 202 spoken lines per language. 58 fixes: Hindi nukta consistency (क़दम, बाक़ी, ख़ुशी, फ़्लोर) and a plural; Tamil sandhi doubling (மெதுவாகச், ஏற்பத்/ஏற்பச், அடுத்துச், அன்றாடச், சுற்றித்); Russian missing "ли", dashes, "сидеть", chakra capitals; Malayalam consistent വയറ്റിൽ / ബോധപൂർവ്വം; English consistent British spelling (symbolise, visualisation, towards) and pose-name hyphens. Owner-pinned spellings kept (മാർഗദർശി, മാർഗ്ഗനിർദ്ദേശകന്റെ നിർദേശങ്ങൾ).

## Completed — Chakra orientation names

- Newcomer orientation lines now say the same chakra name that is on screen, in a confident voice ("It brings steadiness…" instead of "can be a reminder", "is considered"). Hindi मणिपुर→मणिपूर and हृदय/कंठ चक्र now named अनाहत/विशुद्ध; Tamil chakra scripts name அனாஹதம், விசுத்தி, ஆஜ்ஞா, சஹஸ்ராரம் like the screen; Russian uses "чакра" like the labels; clearer body locations (ml അടിവയർ/മേൽവയർ, hi पेट का निचला/ऊपरी हिस्सा); English "3rd Eye" → "Third Eye".

## Completed — Confident, natural narration in all five languages

- Owner: narration felt doubtful ("like giving up"), meditators questioned the benefit. All 181 spoken lines per language rewritten as natural spoken language with calm confidence and clear benefit, no medical or magical claims, safety kept briefly. Hedging phrases cut (English 50 → 0, Hindi 90 → 5, Russian 87 → 9, Tamil 128 → ~20 mostly safety/choice). Gender-neutral throughout.
- Fixed from the narration review: Malayalam Quiet Courage (was about beauty/clothes), വിധിയില്ലാതെ, elbow→wrist in yoga safety; Tamil broken word and Hreem→Om in Third Eye; Hindi masculine narrator/listener forms and Ho'oponopono junk; Russian capital mantras and wrong-stress words; English "close your eyes" and noun lists.
- Engine: sentence pieces keep `? ! . ।`; long sentences break at commas (0.4 s breath) instead of a mid-phrase 1.5 s pause; new `modules/narration-speech-form.js` voice-only respellings (mantras, Chakra, Sanskrit names, Russian capitals, Hindi/Malayalam/Tamil bija). Guide: `docs/narration-style.md`.

## Completed — Calm messages and repertory languages

- Browser alert boxes replaced by translated in-app messages; no developer text shown to users.
- Repertory page in five languages, No Frequency note, app language no longer overwritten.
- Deferred (by choice): lazy-loading locale files; small gain and it would break offline language switching.

## Completed — Lobby frequency reminder

- Owner: No Frequency Mode was only in Settings, so users did not know tones were off. The Lobby now shows the on/off state above Begin with a one-tap switch.

## Completed — Voice download, Sleep wind-down, lighter images

- First voice download is clear: size, offline note, Wi-Fi advice, Download now, MB/percent progress in Settings and a floating pill on any screen, retry on failure, "Downloaded" state.
- Sleep wind-down: final 3 minutes fade to dark and silence; quiet goodnight finish with wake lock released.
- Images served as WebP (about 92% smaller).

## Completed — Heavenly Sound

- Owner: audio must feel crisp, heavenly and smooth, never a strain, with good performance; update the echo. Voice now bypasses the Eyes Close softening (was low-passed at 1 kHz), gets mud cut / de-ess / air; heavenly echo with pre-delay, darkening tail and duck-under-words; Off / Soft Halo / Heavenly; gentle compressor and soft limiter; no exciter colouring, no 40 Hz hum, softer drone repeats, device sample rate. Guide `docs/heavenly-sound.md`.

## Completed — Chakra Touch

- Owner-requested dev-mode couples touch game, third Play Zone card. Fixed roles: one Giver, one Receiver for the whole game (Switch in setup; "Play again: <receiver> gives" at the end). Warm / Close / Spicy 18+ (both players confirm adults). The receiver sets a private Yes/Maybe/No map (No never picked, Maybe asks first), outer body only. Rounds: chakra wheel, touch card, 30–60 s timer with eyes closed, More / Just right / Less. Luck cards (Double time, Your choice, Slow motion), letter tracing, always-visible Pause, check-in every 3 rounds. Private summary, nothing saved. Five languages. Role swap removed (owner: not fun). Module `modules/chakra-touch-game.js`, guide `docs/chakra-touch-game.md`, atlas map `chakra-touch`.

## Completed — Contactless Eye Shooter

- Owner-designed dev-mode gaze game for people with gaze avoidance, as a second Play Zone card. Explanation only (no camera, nothing saved): look at a spot on the partner, hold 3 seconds, blink once, add points. Points 1–5 by difficulty (Eyes and Pubic mound 5). Points goal Short 15 / Medium 30 / Long 50. Five languages. Module `modules/eye-shooter-game.js`, guide `docs/eye-shooter-game.md`, atlas map `eye-shooter`.

## Completed — Hush Hush clarity (v2.0)

- Owner: players took each other's turns and small text changes went unnoticed. Added a press-and-hold hand-off lock on every change of hands, a whose-turn banner, screens tinted in the holder's chakra colour with chakra images, one job per screen (the holder taps; guessers speak), a real chakra wheel, a full-screen result flash with buzz and sound, big luck cards, bigger text and glowing score chips.
- Cards: organs removed; outer parts only (adds Armpit, Navel, Lower stomach). 18+ Secret Card words now Pubic mound, Vagina, Breasts, Nipples, Penis, with an adults-only consent notice before the third game in a row.
- Fixed an old unclosed `@media (max-width: 480px)` block in `style.css` that made game, Pitch and Play Zone styles apply only on small phones.

## Completed — Play Zone and Hush Hush

- Owner asked for a game-like name and an icebreaker subtitle. The game shows as **Hush Hush** with “The icebreaker game for 2–7 players. Spin, guess, laugh.” in all five languages. The Lobby panel now has a **Play Zone** heading so more games can be added as cards. Internal names and IDs are unchanged.

## Completed — Pitch Mode works sitting or standing

- Calm, Energy and Focus openings said "sit" only; all four mood openings now welcome sitting or standing in all five languages, and the Malayalam/Tamil Calm step no longer mentions a seat. A test checks every language.

## Completed — Secret Body Part moved to the Lobby

- Owner felt the Experiment Mode entry was too hidden. The game now has its own dev-mode Lobby panel right after the Mood & Relaxation Ambience section (Play now / Back to Meditation Room). Still hidden and locked until dev mode is unlocked.

## Completed — Pitch Mode (2-Minute Mind Reset)

- Public normal-mode marketing demo between Sound Shot and the Meditation Room. Four moods (Calm, Courage, Energy, Focus; no Rest), voice-guided only, two-minute countdown, invite at the end, no statistics.
- Fixed young male Piper voice per language (English Ryan, Hindi Pratham, Russian Dmitri, Malayalam Arjun, Tamil Rasa); text follows the content language; Settings voice and pace are ignored and restored. New Pitch-only voices are hidden from Settings. Guide: `docs/pitch-mode.md`.

## Completed — Secret Body Part dev-mode party game

- Owner-designed pass-the-phone luck game for 2–7 chakra players, opened from Experiment Mode only while dev mode (Advanced Features) is unlocked. Luck cards, Faker Catch at the Grand Reveal, and a bold Secret Card offered before every third consecutive game. Nothing is saved.
- New module `modules/secret-body-part-game.js` (lazy, offline-cached), five-language strings, `secret-body-game` atlas map, guide `docs/secret-body-part-game.md`. Also fixed two assessment test pins left stale by the previous release.

## Released — 2026-09-30 port of local dev-mode features

- Quiet Courage and the Self-Exploration trio (dev mode only) run as ordered preparation stages after Guided Noting; practice modules load only while unlocked.
- Dev-mode Reverse Journey restored as a session-only Lobby toggle (Crown → Root for selected chakras); roadmap shows “Reverse Journey (Crown ➔ Root)”.
- Lobby roadmap follows runtime order: Arrival/Returning → Intention → preparation practices → Chakras → integration → Closing.
- Production's own skip/floating controls retained. Stale production test pins and moved-code regexes refreshed.

## Completed locally — No Frequency default selection

Fresh profiles now default No Frequency Mode to ON, with both Settings and Journey Tuning checkboxes selected. A previously saved explicit ON or OFF remains respected; an opt-out is not overwritten on reload. The sound-options atlas now records the default and persistence rule. Updated app-state script and shell cache versions. State, No Frequency, audio mode, settings-backup, language/cache and hydration contracts pass. Interactive browser verification was not run.

## Completed locally — single timer in floating journey controls

Consolidated the mirrored upper-corner circular timers into one readable numeric countdown inside the bottom-right control bar. The bar now aligns its timer, Journey Tuning, Pause/Resume, icon-only Skip and Close as one compact row; Skip keeps its localized screen-reader label. Countdown lifecycle, pause behavior and timing cadence are unchanged. Refreshed the app-shell, stylesheet and countdown-module caches. Focused countdown, control, journey-chrome, fullscreen/prelude and spatial-audio contracts pass; browser layout remains for owner review.

## Completed — Piper runtime field and browser preview fallback

Declared and initialized the private `_modelBaseUrl` WeakMap used by community-voice model loading; before this fix, Piper threw a `ReferenceError` and could not load the selected model. On Settings preview failure, the app now speaks the same sample with the first browser voice matching the active language (or system default), reflects that temporary fallback in the picker and reports fallback status. It is not persisted until settings are saved. Piper service-worker assets use a new cache generation to replace stale runtime code. Native browser speech is outside the Web Audio effects chain, so Voice Space applies to Piper playback but not the fallback itself. Focused runtime, fallback and language tests pass; mobile audio was not device-verified.

## Completed locally — Tamil localization and Indic Piper voice setup

Added Tamil to the manifest-backed language picker with a complete UI locale, narration translations and a Tamil Rasa Piper default; registered the community Hindi Priyamvada Piper voice as well. Piper now honors each voice's model repository URL, and registry/manifest plus shell/Piper/language caches are versioned so existing local previews can discover the additions. Service Worker no longer duplicates remote Piper ONNX files already managed by the runtime cache. Focused language, voice-routing, lifecycle and settings-backup checks are listed in the release PR. Hindi model terms remain explicitly marked for confirmation before commercial redistribution.

## Completed locally — CP-MOD-154 Voice tone and echo ownership

`modules/audio-voice-effects.js` owns the unchanged tuning math and Voice Space profiles/routing/ramps. AudioEngine adapters, playback-state order and user flows remain unchanged. Current complete runnable Node sweep passes except `content-safety` and `drone-duration`, which cannot start without owner-managed `docs/dot.json`; browser tests remain excluded. Shell cache has since advanced to v5.324.

## Completed locally — CP-MOD-168/169 audio-owner follow-through

Singing-bowl oscillator lifecycle is covered by the existing tone-playback owner; eyes-closed/audio-filter policy is in `modules/audio-comfort-effects.js`. Exact targets, ramp timing, suppression guards and cleanup are directly tested. The audio map and modularization atlas notes identify both owners. Current runnable Node sweep is 117 passing; the two non-starting tests require the absent owner-maintained `docs/dot.json`. No playback or performance claim is made.

## Merged to production — CP-ASSESS-ADV-UNDO-RAPPORT-001 (PR #78)

The Lobby’s “Begin Session Consultation” CTA is the sole in-app assessment entry point; the duplicate Settings link is removed. It is available only while Advanced Features is unlocked. A 15-minute same-tab grant gates assessment-page startup before question-bank loading and is revoked on relock. Undo removes the latest response; results show chakra-only conversation prompts and a client-led icebreaker. They do not predict character or behavior and exclude value-priority answers and the private dot. PR #78 was merged to `production` as `d0a8051` on 2026-09-26. Focused assessment and unlock tests pass; the atlas rebuild succeeds. Browser atlas verification could not launch Chromium; visual review remains pending with the owner. GitHub reported no CI checks.

## Merged to production — consultation CTA Advanced Features visibility (PR #78)

`Begin Session Consultation` starts hidden and disabled in static Lobby markup, becomes visible only through the shared Advanced Features unlock, hides and disables again on relock, and rejects direct click activation while locked. The service-worker shell cache is bumped so installed/local clients receive the changed `index.html` and `app.js`; cache-version assertions follow it. The overview atlas reflects the gated Lobby path. The standalone assessment URL itself is not protected by server authentication; this correction gates the in-app CTA only. PR #78 merged to `production`; focused regression tests pass, while browser visual review remains pending.

## Completed — CP-MOD-066 Timing duration settings view ownership

Seven transition-duration and three care-duration input handlers now live in `modules/timing-settings-view.js`. Preserve integer parsing, shared state updates, localized display helper calls, saved `chakra_time_*` keys, update order, listener attachment positions and the existing estimate/roadmap refresh. Mode-sensitive chakra/Sleep/Shot and High Energy duration controls remain app-owned. Eager delivery is an ownership/testability extraction, not a performance gain.

## Completed — CP-MOD-061 Journey content loading and validation ownership

Start-time script source selection, cache reuse, fetch and required-bundle validation now live in `modules/journey-content-loader.js`. The app retains script/session state; the resolved bundle is committed before validation, validation context is captured at the same point relative to asynchronous loading, and fetch URLs and failure messaging are unchanged. No behavior or performance change is claimed.

## Completed — CP-MOD-060 Guided opening and Gratitude stage ownership

The shared opening/Gratitude stage now lives in `modules/journey-opening-stage.js`. Preparation-safety guidance, optional Arrival induction, Moon/Returning branch, Gratitude, personal intention, HRIM opening, and optional Arrival readiness retain their original order and guards. No behavior or performance change is claimed.

## Completed — CP-MOD-059 Arrival and Emergence wrapper ownership

The optional Arrival/Arrival-readiness cues and Emergence sequence now live in `modules/journey-hypnosis-wrapper.js`. App adapters retain journey behavior, stage order, frequency/no-frequency branches, configured timing, fade windows and cancellation guards. This changes ownership only.

## Completed — CP-MOD-058 Music echo preset ownership

The existing music echo profiles and parameter ramps now live in `modules/audio-music-echo.js`; the AudioEngine method and settings persistence stay stable. Preset values, invalid-mode fallback, 250 ms ramps and convolver-tail timing are unchanged. No performance claim is made.

## Completed — CP-MOD-057 Background-music gain and fade controls

Background-music fades, volume-role preservation, stage ducking, mantra mute/restore, tail-gate automation and restore-timer cancellation now live in `modules/audio-background-music-controls.js`. Stable AudioEngine methods, journey callers and cache delivery remain intact. No performance claim is made.

## Completed — CP-MOD-054 Binaural and drone cleanup lifecycle

`stopBinaural()` and `stopDrone()` resource retirement now live in `modules/audio-drone-stop.js`; the AudioEngine API remains stable. Pre-context state clearing, AudioParam filtering, 5-second gain fades, delayed stops and cleanup ordering are unchanged. The module is eagerly available and cached for offline sessions. No performance claim is made.

## Completed — CP-MOD-053 Chakra and sleep drone startup

Drone startup generation now lives in `modules/audio-drone-start.js`; public AudioEngine adapters, `stopDrone()` lifecycle, No Frequency checks, chakra and sleep frequency policies, binaural support, and journey call paths remain unchanged. The module loads eagerly and is precached for offline playback. No audio or performance improvement is claimed.

## Completed — CP-MOD-052 Generated tone playback lifecycle

Frequency-only Shot and guided transition-tone generation, validation, fades and disposal now live in `modules/audio-tone-playback.js`. AudioEngine method names remain compatibility adapters; UI call paths, No Frequency behavior, volume caps and routing are unchanged. The module is eagerly available and precached for offline journeys. This is ownership/testability only.

## Completed — CP-MOD-051 Elemental audio-layer lifecycle

Elemental noise-bed generation, per-chakra filter selection and source/LFO cleanup now live in `modules/audio-elemental-layer.js`. AudioEngine retains the public adapter and noise-buffer cache; chakra-index routing, settings and journey call order are unchanged. The module is loaded eagerly and precached offline. No audio quality or performance improvement is claimed. See the modularization review and active handoff.

## Completed — CP-MOD-050 Audio spatial geometry

Generic Web Audio panner construction and position interpolation now live in `modules/audio-spatial-geometry.js`. The AudioEngine's public methods remain adapters; spatial mode profiles and behavior remain unchanged. The helper loads eagerly and remains in the offline cache. No spatial-audio or performance benefit is claimed. See the modularization review and active handoff.

## Completed — CP-MOD-049 Audio signal design helpers

Soft-clipping curve, seeded diffuse reverb, stochastic impulse response and white-noise buffer generation are implemented in `modules/audio-signal-design.js`. AudioEngine retains its public adapters and cached-noise state; existing call order and algorithm inputs are preserved. The module is eager and offline-cached. No sound-quality or performance improvement is claimed. See the modularization review and active handoff.

## Completed — CP-MOD-048 AudioEngine initialization graph ownership

The one-time Web Audio graph construction now lives in `modules/audio-engine-initialization.js`; `AudioEngine.init()` remains the public adapter and passes existing state/constants explicitly. Node topology, parameter values, output-selection fallback and call order are preserved and directly mock-tested. The new module remains eager and offline-cached; this is ownership/testability work only, with no audio-quality or performance gain claimed. See the modularization review and active handoff.

## Completed — CP-MOD-043 chakra visual-effect controller ownership

The existing `VisualEngine` now lives in `modules/visual-engine.js` and is eagerly loaded/cached before the app. The same single instance still receives the existing `AudioEngine`; effect modes, Eyes Close handling, chakra glow, slow image breathing and stop cleanup are unchanged. CSS and persisted settings remain in their existing owners. This improves code ownership only; startup JS is effectively unchanged and no device/thermal gain is claimed. See the modularization review and active handoff.

## Completed — CP-MOD-044 standard journey duration-estimate ownership

The exact standard chakra-journey duration calculation now belongs to `modules/session-estimate.js`; `MeditationController` delegates with the same app-owned state, script, localization, timing, narration and DOM services. Session dispatch, mode priority and legacy fallbacks remain in the controller. This is ownership/testability work only; no performance or thermal gain is claimed. See the modularization review and active handoff.

## Completed — CP-MOD-045 exact session countdown-duration ownership

`modules/session-estimate.js` now owns the exact per-mode milliseconds calculation for Music Only, focused practices, combined preparations, Yoga, Intimate Service, Sleep, measured standard narration and HRIM/demo fallbacks. `MeditationController` supplies app state and DOM-derived values, and still owns timer lifecycle and route entry points. Duration formulas and precedence are covered directly; eager loading remains unchanged and no performance or thermal gain is claimed.

## Completed — CP-MOD-046 session countdown lifecycle ownership

The exact countdown ticker state and 250 ms lifecycle now live in `modules/session-countdown.js`; the controller injects active/paused state, browser timers, clock and existing show/hide display callbacks. Controller call sites, route behavior, and estimate formulas are unchanged. Direct fake-clock tests cover elapsed-time accounting, paused/inactive time, restart, invalid durations, zero clamping and cleanup. Eager delivery adds no performance or thermal claim.

## Completed — CP-MOD-047 newcomer marker layout lifecycle ownership

The seven normalized chakra anchors, responsive SVG connector geometry, frame coalescing, image-load and resize triggers, and explicit cleanup now live in `modules/newcomer-marker-layout.js`. The newcomer screen, labels, narration, placement formulas and journey order remain unchanged. Direct deterministic geometry/lifecycle contracts and the existing newcomer journey checks cover parity. Eager delivery adds no visual, startup, CPU, memory or thermal claim.

## Completed — CP-MOD-042 observational sky renderer ownership

The existing `AmbientParticleField` renderer is now owned by `modules/ambient-particle-field.js` and loaded eagerly after its astronomy dependencies. The app still creates one instance and uses the same callbacks; canvas drawing, observer location/time, Earth/Moon/Sun/planet/star visibility, atmosphere, protective illustration, reduced-motion/static journey behavior and cleanup are unchanged. The module is included in the exact offline shell cache. This extraction improves ownership only; it does not claim startup, CPU or thermal gains. See the modularization review and active handoff.

## Completed — CP-MOD-041 lazy video-introduction controller

The `JourneyVideoPrelude` controller is no longer parsed or constructed at startup. It loads on the explicit Lobby video-introduction path or Settings audio preview; simultaneous requests share one load, and a failed module load falls through to the ordinary journey. Its code remains in the offline shell cache, while the large video remains uncached. Browser checks confirm no initial module/video requests, on-demand loading for both entry points, and offline shell availability. No device/thermal benefit is claimed from the local sample. See `.loop/tracks/modularize/review.md` and `.loop/tracks/modularize/HANDOFF.md`.

## Completed — CP-MOD-040 shared journey chrome ownership

Fullscreen tracking, hidden controls, pointer/focus/touch reveal, idle cursor, mixer visibility and timer cleanup now belong to the shared eager `JourneyChromeController`, not the optional-video controller. Its interaction timings and session behavior are preserved. This is an ownership extraction, not a performance claim. See the modularization review and active handoff.

## Completed — CP-MOD-039 optional video startup request

The optional 7.3 MB video introduction and its Settings preview no longer trigger media loading when the app starts. The URL is attached only when a user starts the explicitly opted-in introduction or requests preview; the clip remains outside service-worker precache, so offline requests use the existing safe unavailable-video path. Regression coverage observes actual browser requests before and after opt-in. This avoids unneeded media transfer/decoder work on ordinary sessions; CPU/thermal improvement is not measured. See `.loop/tracks/modularize/review.md` and `.loop/tracks/modularize/HANDOFF.md`.

## Completed — CP-MOD-038 selected guided-practice loading

Box Breathing, Visualization, Dharana, Body Scan, Guided Noting, Ho’oponopono and Undo & Unlearn scripts are cached offline but excluded from eager page scripts. Begin loads only selected modules, before video/audio; a failed load blocks session start, displays a localized retry message and permits another attempt. Existing route/lifecycle contracts remain active. Local Chromium confirms zero practice scripts initially and only Box Breathing loads from cache after selecting it and starting offline. The observed initial-JavaScript body reduction is ~13.1 KiB in this harness; device/thermal gains are unproven. See the modularization review/handoff.

## Completed — CP-MOD-037 offline shell cache parity

The local browser baseline found that versioned `app.js`/`style.css` requests did not match unversioned service-worker precache entries, breaking offline reload. Cache entries now match the exact `index.html` URLs, and the opt-in Chromium test covers cold, warm and offline startup without starting audio. The next approved investigation is selected-only practice-module loading, gated on route parity, offline cache behavior and failure/retry coverage. See `.loop/tracks/modularize/review.md` and `.loop/tracks/modularize/plan.md`.

## CP-MOD-036 — Personal-care preference hydration

Perineal-care, assisted-bathing and massage controls display their already-loaded preference values. Session authorization and execution are unchanged.

## CP-MOD-035 — Script preference hydration

The current saved script source selects the default/custom UI, and loaded custom scripts keep their existing status copy. Loading, validation and demo-timing decisions remain app-owned.

## CP-MOD-034 — Appearance preference hydration

Visual-effect and brightness control presentation follows the existing saved state and app-owned image renderer. Script selection, status messaging and voice selection remain in `loadPreferences`.

## CP-MOD-033 — Timing control presentation hydration

Core and auxiliary duration values are copied into current controls with their existing range-fill and unit labels. Stored timing defaults/clamping, duration calculations and drone-duration selection remain in their current owners.

## CP-MOD-032 — Journey-selection hydration

Selected chakras, the existing intention fallback and returning/video/audio-filter control state are applied by a tested owner. The app still owns stored state, validation, mode gates and journey dispatch; no route or saved preference semantics change.

## CP-MOD-031 — Mixer preference hydration

The ordered 19-item mapping from app-owned mixer settings into Lobby/Settings controls has a dedicated tested owner. Preserve duplicate mirror controls and its current loadPreferences position; it does not own persistent state or audio-engine tuning.

## CP-MOD-030 — Session-only mode reset ownership

App-load cleanup of retired Box Breathing, Ho’oponopono, Music Only, High Energy and Sleep mode keys and checkbox defaults now has a dedicated owner. Yoga mode/setup restoration remains app-owned; persisted care/pose preferences are not cleared. This is eager ownership-only work, with no performance claim.

## CP-MOD-029 — Automatic journey voice profile ownership

The existing High Energy, feminine-voice Shringara and default soft profile branch has moved to a direct-testable module. Preserve profile values, storage keys, saved settings, control/preset synchronization and optional audio tuning behavior. This remains an eager ownership extraction, not a performance optimization. Device listening/quality validation is not claimed.

## Production release E2E gate corrections — local validation complete

Standalone preparation choices now launch without chakra selection, execute in the shown order, receive a matching standalone roadmap and include their durations in the session countdown. During an active journey, once mouse movement reveals the controls, the bottom reveal area yields pointer interaction to the controls. E2E checks were corrected for current selectors, script JSON fields, voice minimum and session-only HRIM mode. Full browser suite: 26/26 passed; atlas: 32 maps verified. Production publication remains a separate approved action; device playback/thermal validation is not claimed.

## Measured lazy loading — after extraction parity

The CP-MOD-011 baseline is a single indicative local cold Chromium sample: 13 classic scripts execute before Lobby (about 849 KiB encoded JS bodies), 6.7–7.5 MB reported JS heap and 0.73–1.07 s ScriptDuration. The local server does not compress; the harness blocks Google Fonts. Re-run the same cold/warm/offline and journey-start profile after extraction. These figures do not yet justify a specific dynamic-import boundary or establish a production performance gain. Preserve the small eager shell and choose cohesive optional bundles only after parity; defer implementing lazy loading until stable ownership, offline/error paths and cleanup contracts are testable.

## CP-MOD-067 — custom script settings ownership

Moved the default/custom source selector, file-upload handler and URL-fetch handler into `modules/script-source-settings.js`. Demo timing, estimate/roadmap refresh, panel visibility, persistence, validation feedback and journey-script cache invalidation are covered. URL loads use latest-nonempty-request-wins; stale completions cannot replace the winner or its status. Empty URL is a no-op. HTTP, JSON and schema failures preserve the previously accepted custom script/cache. The atlas now has a dedicated custom-script settings map for success, retry, failure and stale-request paths. This is ownership work only; no performance claim.

## CP-MOD-068 — Mood & Relaxation ambience URL view ownership

Moved the existing Journey Tuning/Lobby custom ambience URL button handler and localized loading/result status into `modules/mood-ambience-settings-view.js`. Empty URL still clears the custom replacement; load success, failure status, control resync, and the button's No Frequency disabled state are unchanged. `AudioEngine.loadPleasureAmbienceUrl()` retains URL loading, validation and persistence. Focused tests cover success, clear, error recovery and disabled-state restoration. Ownership only; no performance claim.

## CP-MOD-011 — ordered preparation execution ownership

Journey routing now executes the existing stage callbacks in canonical order and checks session activity before each stage. The stage implementations and their UI/audio/narration ownership stay in `app.js`; no user-visible flow is intended to change. Atlas map `modularization` records the boundary and `journey-addons` records the cancellation guard.
## Operator acceptance — assessment tournament follow-up

The software checkpoint is integrated and automated/browser-tested: one prompt at a time, non-repeating answers, seven chakra results, positive archetypes, private patterned service-fit dot, sanitized resume/reset and Google Translate dynamic strings. Schedule a trained-operator review of neutrality, interpretation and real-session usability. This is an acceptance follow-up, not a blocker to the tested software merge; do not add medical diagnosis, direct intimate-service questions or automatic recommendations.

### Assessment result clarity — implemented

Removed the misleading 100% “reflection confidence” presentation. Each chakra now shows its actual answered-response count and a relative answer-support label. The operator result can surface one lowest-support chakra or close candidates only after every chakra meets minimum evidence; insufficient coverage and non-differentiating near-ties instead receive a client-led prompt. This is exploratory conversation support, not a measured weakness, diagnosis or automatic session recommendation. The dynamic labels continue through the existing Google Translate cache. Focused engine/UI/persistence tests pass; browser visual review remains with the owner.

### Assessment answer-support visual cue — CP-ASSESS-IMPL-004

Added a compact three-segment indicator and legend to result cards: muted lavender for Lower, soft amber for Mixed and cool aqua for Higher answer-support. The visible text status and response count remain authoritative; insufficient-evidence cards stay neutral. A possible discussion-focus card has a separate gold outline and text tag. Scoring and focus thresholds are unchanged. Browser visual verification remains owner-pending.

## Content-free Undo & Unlearn integration — release 3.51 candidate

Added an optional 5/8/12-minute pitch-black integration after Ho’oponopono. It requires no recall, answer, speech, typing, examples or contact; separates three forgiveness possibilities; preserves responsibility/boundaries; and never claims another person has forgiven the meditator. Four-language source coverage and sequence guards are required; device listening remains open.

## Cosmic Consciousness video subtitle — release 3.50

The optional Lobby video introduction now has a localized “Cosmic Consciousness Introduction” subtitle in all four languages. Playback behavior is unchanged. Production push authorized with the pending Body Scan and Guided Noting preparation release.

## Guided Noting preparation — release 3.49 candidate

Added a selectable 2/4/6-minute Guided Noting stage after Body Scan. It uses neutral labels, four spaced reminders, choice-based safety language, a pitch-black no-loop screen, standalone preparation routing, roadmap/estimate integration and four-language narration. Device listening remains open.

## Guided Body Scan preparation — release 3.48 candidate

Added a selectable 3/5/8-minute Body Scan with eight localized head-to-toe narration regions, whole-body closing, standalone preparation routing and journey estimate/roadmap integration. Its screen is a plain pitch-black fade; the body figure and scanning light were removed by owner request. Preparation order is Box → Visualization → Dharana → Body Scan → chakras. Automated source, language and thermal checks pass; device listening remains open.

## Yoga Advanced Features gate — release 3.47 candidate

Yoga Experience now shares the session-only Advanced Features gate: hidden/disabled while locked, enabled after the password unlock, cleared on relock/reload, and protected against direct locked selection or start. Automated lock lifecycle checks are required; device UI verification remains open.

## Four-language add-on narration coverage — release 3.47 candidate

Audited every spoken segment in Box Breathing, Dharana, Guided Visualization and Ho’oponopono for English, Malayalam, Hindi and Russian. Restored the two empty Malayalam Box Breathing hold prompts as “ശ്വാസം പിടിച്ചുവയ്ക്കുക”. The focused-practice contract now rejects missing/empty narration and incorrect Box-step or Ho’oponopono-phrase counts. Source coverage passes; pronunciation and target-device listening remain open.

## Journey add-on selection and visual release — release 3.46

Box Breathing and Ho’oponopono no longer clear themselves when checked. Box Breathing, Dharana, Guided Visualization and Ho’oponopono can be combined, while replacement experiences still clear all add-ons. Dharana now uses a pitch-black full-screen scene and releases its anchor/veil while the closing narration runs; Visualization's black-overlay transition remains active under static-journey performance mode. Automated source, language, audio-transition and thermal-budget checks pass; device playback remains open. Production push authorized.

## Dharana closing narration — release 3.46

After the selected focus interval, active sessions now keep the anchor visible while a localized closing releases the gaze and widens awareness to breath, body and surrounding space. Visual cleanup follows the narration; stopped sessions skip it. English, Malayalam, Hindi and Russian are included. Automated source/language checks pass; device listening remains open.

## Centered directions and journey snapshot — release 3.45

Directions now have equal viewport insets and spacing; the entire sky projection shifts with them so labels remain correct. Journey redraws no longer recalculate astronomical positions; no ten-second update occurs during journeys. Lobby/Settings keep the bounded update. Protective Earth/Sun artwork is retained. Production push authorized.

## Retained protective artwork visibility — implemented locally

App 3.44: Earth's five atmospheric gradients are stronger outside its opaque limb, including on tiny markers; the innermost layer expresses a cool-aqua 26°C comfort theme (no temperature label or physical claim). Outer footprint, text-clearance guards and static performance remain unchanged. Earth atmosphere and the Sun shield are now explicit owner-retained features in `AGENTS.md` and both atlas maps. Removal/default disabling/substantial fading requires owner approval; unit and actual browser-pixel/render-path tests guard against accidental loss. Device review remains open.

## Observer sky and Earth atmosphere — implemented locally

2026-09-17: removed the decorative daytime planet row, random background stars and daytime Moon suppression. Real stars and topocentric solar-system bodies share a zero-altitude horizon; denied location is explicitly a Greenwich reference. Earth remains below-horizon artwork with softly merged atmosphere layers. Calculation failures clear stale positions and bound retries; static journeys keep no repeating work. NASA reference, unit and desktop/mobile browser checks pass. Live-sky/device thermal and offline upgrade checks remain open; see `../SKY-ACCURACY.md`.

Earth adaptation: centered observer marker below the horizon; shrink/omit guards protect foreground text/controls, including their reveal position. Five softly merged atmospheric layers and a feathered Sun shield ring remain visual-only. Layout events cause a coalesced redraw, not idle polling.

Historical test baseline: 34/37 non-browser tests passed at the original sky-checkpoint audit. The old `chakra-selection` source assertion was later updated to follow the extracted Lobby-visibility owner and passes on the current modularize branch. The two fixture-dependent `content-safety` and `drone-duration` contracts still require owner-managed `docs/dot.json`; without that fixture they remain excluded, not passing.

## Newcomer chakra orientation — implemented locally, device check pending

When Returning Journey is unchecked on a normal chakra journey, Begin proceeds directly to a short orientation before Arriving. A static night-sky standing body-map illustration marks each chakra name and body location in the chosen Display Language. Responsive calibrated arrowheads terminate at their matching points. The spoken orientation follows the chosen Meditation Language; its Malayalam copy uses short, natural spoken sentences and the Malayalam chakra names. The app switches explicitly to Arriving afterward, removing the previously visible welcome-screen flicker. Returning Journey, demo, Sleep, Music Only and focused practices bypass this screen. Automated source contracts and a targeted browser flow cover the branches; a user device readability and listening check remains open.

## Lobby video introduction — implemented locally, device check pending

The video introduction is an explicit persisted Lobby preference, OFF by default. When selected, the roadmap adds Video Introduction and the video buffers and plays before the normal journey dispatcher continues. Completion acknowledges the Do Not Disturb reminder once; an unavailable video still continues into the chosen journey. Restart Journey is now immediate and does not replay the video. The readiness-only dark shade is removed during actual playback, so the video uses its authored brightness and contrast. Automated source contracts cover routing and full-brightness behavior; a device playback/color check remains open.

## Newcomer body-map artwork labels — implemented locally, device check pending

The standing body-map artwork carries fixed English chakra labels and restrained leader lines. The responsive Display Language labels and connector arrows remain available for localized location guidance but render at reduced opacity, so the image’s fixed labels remain the primary visual reference. The asset, responsive-overlay contracts and atlas are synchronized; a device readability check remains open.

## Sleep Mode shared unlock — implemented locally, device check pending

Sleep Mode now shares the seven-rapid-tap App version Advanced Features unlock with Intimate Care, Shots and Manage Settings. It starts hidden/disabled, relock clears it, reload starts locked, and both UI and direct journey entry reject it while locked. Automated lock and atlas checks pass; user visual/device journey check remains open.

## Advanced Settings backup — implemented locally, device check pending

The shared seven-tap Advanced Features unlock now reveals a Manage Settings CTA in Settings → About. Its page exports only this app’s `chakra_` saved preferences as a versioned JSON backup. Import accepts a bounded, validated backup, asks for confirmation, replaces only those app keys and reloads; it never uploads settings or changes unrelated browser storage. Focused tests and atlas verification pass; visual/device import/download confirmation remains open.

## Shots shared unlock — implemented locally, CP-SHOTS-001

Shots heading/controls now share the seven-rapid-tap App version unlock with Intimate Care. Relock clears both selections; reload starts locked. No Frequency and confirmation remain. Repertory URLs wait for unlock before preparation; direct locked Shot execution is rejected. Static/mock tests pass; user visual check pending. Corrected obsolete four-click wording in the care map.

## Sleep controls clipping — fixed locally, device check pending

Sleep/Eyes Close dimming no longer filters ancestors of viewport-fixed controls. Brightness composes through opacity; warmth remains on artwork/sky only. This removes the identified containing-block cause of drifting/clipped controls. Source/mocked regression checks pass; actual Sleep layout still requires user verification.

## Journey cursor and controls — implemented locally

Cursor idles out after 3s. Bottom controls including mixer toggle reveal on hover, touch or keyboard focus in normal/fullscreen journeys, with open-mixer and exit cleanup guards. Mock interaction tests pass; device verification remains open.

## Stage-aware fades — implemented locally, listening check pending

Arrival/Interval/Emergence music transitions use 20% of the stage setting capped at 3s. The default post-mantra pause remains 4s, now containing a 2s chant fade and 2s wet-tail fade before affirmation. Long final-session tails remain. Stage timing and failure-cleanup tests pass; device listening remains open.

## Longer audio exits — implemented locally, listening check pending

Mantra entry no longer zeros the retiring chant bus; loop entry/exit envelopes are independent and repeated Stop is idempotent. Mantra/music exits are eight seconds with longer reverb responses; session Piper cancellation fades for two seconds plus its tail. Browser speech cannot use the Web Audio fade chain and retains immediate explicit cancellation. Source/mock checks pass; reported device audibility remains to be checked.

## Thermal workload reduction — implemented locally, device check pending

Static sky and decorative effects outside Lobby/Settings; bounded 180-code-point Piper chunks, one future clip with duration-triggered preparation, a 16 MiB/48-entry memory cache and idle/Off reverb disconnection are implemented. Source and automated checks cover these paths. Device heat/CPU and the reported early journey exit remain unverified. Earlier narration-scroll notes below are historical; scrolling narration is now removed.

## Long playback follow-up — implemented locally, 2026-09-09

Removed JavaScript repeat scheduling, repaired elemental LFO cleanup, moved decoding/normalization ahead of speech, added cancellation guards, bounded phonemizer reuse and inference tensor disposal. `audio` and `narration` maps reflect the implementation. Native PCM/mock and real phonemizer checks pass; full synthesis, thermal profiling and device listening remain open. Narration scroll and intentional pauses remain.

## Performance pass — implemented locally, 2026-09-09

The `visuals` map now includes cached celestial rendering, sleeping frame schedulers, hidden-page animation cancellation and transient audio-node cleanup. Automated cache/lifecycle and existing audio/visual checks pass. Device thermal profiling is still open; this does not establish that every source of heating has been removed. See the active performance entry in `HANDOFF.md` for the matched-scene device check.

Baseline: `production` at `6a0ee84`, inspected 2026-09-08. These are proposed sequential changes, not changes already made. The atlas records the current behavior before fixes.

## 1. Restore a useful test baseline

The content-safety and drone-duration test commands read absent owner-managed `docs/dot.json` before reaching their assertions. The other 21 non-browser commands passed in the initial review.

Separate production assertions from optional facilitator-fixture checks. Keep explicit coverage for a supplied fixture, and clearly report when that optional fixture is absent. Do not recreate or overwrite the owner's facilitator content. Acceptance: production checks execute and pass without this private file; malformed supplied fixtures still fail meaningfully.

Sources: [content-safety test](/Users/lekshmisyam/Desktop/Ikigai/lite/tests/content-safety.test.mjs:7), [drone-duration test](/Users/lekshmisyam/Desktop/Ikigai/lite/tests/drone-duration.test.mjs:11).

## 2. Correct experiment countdown units

The UI assigns `dataset.unit` as `sec` or `min`, but `startExperiment` only recognizes `seconds` as seconds. Box and Corpse countdowns are therefore interpreted as minutes. Bath/care controls carry values consumed as seconds by their routines but are labeled `min`. Ho’oponopono also reads a hidden duration value despite having no duration control.

Define one activity-duration contract and derive control labels, stage arguments and total estimates from it. Box duration is a per-step duration, so a total estimate must account for four steps × four cycles plus guidance. Acceptance: a 60-second care value displays as one minute and does not produce a 60-minute countdown; Box clearly distinguishes step duration from session estimate; Ho’oponopono does not inherit another activity's hidden value.

Sources: [startExperiment](/Users/lekshmisyam/Desktop/Ikigai/lite/app.js:4716), [experiment UI](/Users/lekshmisyam/Desktop/Ikigai/lite/app.js:7481). Map: `experiments`.

## 3. Resolve massage → assisted-bathing closing behavior

`runIntimateService` invokes `runSequence({complete:false})` when assisted bathing follows massage. This skips silence, closing and finish. After bathing and guide Continue, the outer focused route calls `finish()` directly; no deferred closing is invoked. The nearby comment says closing is deferred, which disagrees with execution.

Choose the intended closing placement from this concrete path, then make code, flow map and tests agree. Do not accidentally add ordinary Arrival/Emergence wrappers to standalone care. Acceptance: every selected care combination completes exactly once; if deferred closing is intended, it runs once after assisted bathing, and cancellation prevents it.

Sources: [care composition](/Users/lekshmisyam/Desktop/Ikigai/lite/app.js:5507), [sequence](/Users/lekshmisyam/Desktop/Ikigai/lite/app.js:5428). Map: `care`.

## 4. Make offline startup and upgrades deterministic

The service worker precaches unversioned `app.js`, `style.css` and `scripts.json`, while HTML requests versioned shell URLs and journey loading appends timestamp queries. Its general request handler uses exact `caches.match(request)` and does not cache misses. Those paths can fail offline despite a populated shell cache. Activation also deletes caches outside three exact names, without restricting deletion to this app's namespace.

Registration is attached to `window.load` only after async initialization, so a late registration listener can miss that event. Verify this race and register deterministically. Establish an explicit update and query-key policy that preserves version correctness, limits cache deletion to this app, and defines which media can be available offline.

Acceptance: after an online warm visit and successful installation, offline reload and a standard journey load the intended assets; an update does not mix generations or erase unrelated caches. Optional video/model first-use downloads remain clearly distinguished from cached content. Browser checks must enable service workers for these scenarios.

Sources: [service worker](/Users/lekshmisyam/Desktop/Ikigai/lite/sw.js:1), [registration](/Users/lekshmisyam/Desktop/Ikigai/lite/app.js:6205), [script loading](/Users/lekshmisyam/Desktop/Ikigai/lite/app.js:4566), [test configuration](/Users/lekshmisyam/Desktop/Ikigai/lite/playwright.config.js:18). Maps: `startup`, `storage`.

## 5. Check cancellation, duplicate starts and estimates by journey family

Source review shows multiple start/stop implementations rather than one state transition mechanism. `runSleepJourney` checks `isStarting` but does not claim that guard before fetching content. Natural Shot completion reloads; manual Stop and Shot failure use different cleanup paths. Music Only has a separate activation path. These are concrete places to test rapid actions and delayed loads, not all proven failures.

Sleep's real inter-stage gap is 3 seconds while its estimate uses script intervalSeconds. Care/Yoga guide waits are unbounded; estimates cannot count time the guide has not yet chosen. Completion statistics use elapsed wall time, including pauses. Decide what time each display represents and make labels and calculations agree.

Acceptance: fast double Begin, Stop during fetch/synthesis, Pause during narration, Restart while unwinding and guide cancellation do not start an abandoned stage or leave audio running. Test each family’s own exit behavior rather than assuming shared finish().

Maps: `modes`, `sleep`, `controls`, `restart`, `completion`, `recovery`.

## 6. Improve behavioral evidence before restructuring

Many current checks assert source text. Add a small set of executable journey-transition tests and targeted browser checks for the behavior being fixed. Keep source contracts where they are useful, but avoid equating a regular-expression match with successful playback. Target-device listening and mobile lifecycle checks remain separate evidence.

## 7. Separate modules and simplify the user-facing setup

After behavior is stable, extract bounded areas such as configuration/content, audio, narration, journey orchestration and visuals from `app.js`. Preserve behavior between extractions. Use this atlas to identify shared dependencies and update source references after each extraction.

A later product-design pass can distinguish a simple participant entry from advanced facilitator controls. That is a design change, not a prerequisite for fixing the concrete defects above.

### Modularization track — active on `modularize`

CP-MOD-012 through CP-MOD-027 are integrated on `modularize`: all journey practices have directly tested lifecycle owners, shared screen switching preserves the Lobby/Settings dynamic-sky exception, Lobby session estimates are isolated, Mood & Relaxation and drone-duration Settings have view owners, central Lobby experience visibility has a directly tested controller, Yoga setup persistence/timing-row presentation has a directly tested owner, shared range controls have an isolated tested renderer, localized display-only journey roadmap ownership is extracted, and display-language UI painting is isolated. CP-MOD-028 is in progress for timing configuration/profile ownership. Modules remain eager and precached; no performance gain is claimed. Browser/device evidence limitations remain in checkpoint review. Lazy loading stays gated by extraction parity and repeated cold/warm/offline measurements.

The atlas-led migration is now active. Delivered seams move settings backup operations into `modules/settings-backup.js`, initial state into `modules/app-state.js`, content path lookup/language fallback/script validation into `modules/content-localization.js`, deterministic media primitives into `modules/media-lifecycle.js`, Piper worker/synthesis/playback ownership into `modules/piper-lifecycle.js`, effect-route connect/tail-retirement ownership into `modules/audio-route-lifecycle.js`, and deterministic journey start routing plus the ordered preparation-stage plan into `modules/journey-routing.js`. All expose frozen APIs and preserve classic-script startup order. Web Audio bus construction was explicitly deferred until the next weekly reset; CP-MOD-048 is now resuming that boundary after the reset and is active in its own checkpoint. Each boundary must retain behavior, update its atlas ownership/source references, remove source-slicing tests where touched, and pass a focused parity gate before the next extraction. Native ES-module conversion and optional-feature lazy loading remain later decisions, not completed behavior.

CP-MOD-054/055 are integrated on `modularize`: binaural/drone stop cleanup and recorded mantra start/stop are separately tested audio owners. CP-MOD-056 is in progress on its isolated checkpoint branch, extracting background-music loop start/stop while gain/restore policy remains app-owned. Keep all audio modules eager and precached until parity is complete; the final lazy-loading phase still requires repeatable cold/warm/offline browser evidence and explicit opt-in browser verification.

### Planned post-parity performance phase

Do not begin this phase until the bounded module owners, AudioEngine extraction and UI controllers reach behavior parity. First record cold/warm/offline startup, parsed/executed script cost, journey-start latency and active worker/audio/animation resources. Keep state/settings, localization, Lobby controls, journey routing and lifecycle safety in a small eager shell. Consider cohesive optional bundles—Advanced/Yoga/Intimate/Experiments, Sleep, video introduction, specialized preparation practices, Piper runtime/model and optional spatial effects—only where measurements justify the boundary. The service worker may cache those bytes for offline use without executing them at startup. Preload only after selection or clear intent, deduplicate concurrent imports, provide a safe localized load failure, and make Begin await unfinished preparation. Add explicit release contracts for workers, decoded buffers, AudioNodes, media sources, animation/WebGL owners, observers, timers and listeners. Accept a boundary only after cold/warm/offline, cancellation/restart, PWA-update and route-regression evidence shows a worthwhile memory, CPU or startup improvement without harmful start delay. This is `PLANNED`, not delivered behavior.

## Working order

### Approved delivery workflow

CP-WORKFLOW-001/002 makes isolated worktrees and focused pull requests the default for substantial, risky, experimental or parallel checkpoints while automatically selecting a cheaper Caveman/Focused path for tiny bounded work. Substantial work builds a task-scoped AST/symbol dependency map; ephemeral specialists are allowed only for independent high-value subtasks and return unified diffs/findings to the sole integrating agent. Durable resume packets permit fresh-session resets without replaying chat history, and the Loop router selects the least-cost capable tier while recording recommendation versus actual dispatch. Every sandbox receives bounded context, one checkpoint and declared file ownership; only one sandbox may own shared atlas, app-shell, service-worker, settings-schema, translation or audio-engine surfaces at a time. Pull-request readiness requires fresh targeted checks, two-stage review, synchronized atlas/handoff and a validated checkpoint commit. Approved remote merges are synchronized back to the local integration branch before combined regression checks; production publication remains separate. See `.loop/workflow.md` and the `delivery-workflow` atlas map.

CP-WORKFLOW-003 corrects automatic-tier inflation discovered during the first ephemeral assessment review. A bounded packet may wrap only its classification objective in `[LOOP_CLASSIFY]...[/LOOP_CLASSIFY]`; the router classifies that slice and still sends the complete safety constraints to the child. This prevents phrases such as “do not delete” from selecting the expensive high-risk lane while preserving high-risk routing for actual unmarked release/push/destructive requests.

### Approved visual checkpoint after assessment and modularization

CP-THEME-PLAN-001 adopts the Cosmic Observatory desktop/mobile concept saved under `docs/design/lite-cosmic-observatory/`. CP-THEME-IMPL-001 implements the Lobby foundation; CP-THEME-IMPL-002 adds localized Settings → Sky Observatory navigation; CP-THEME-IMPL-003 completes supporting surfaces and restores one-shot static sky frames on journey/support pages. Only Sky Observatory animates, while Lobby/Settings remain clear. Owner browser review and feedback corrections remain. The generated mockup is an appearance reference, not astronomy: its omissions, sample timing, cardinal arrangement and curved horizon are not implemented. Browser and measured-performance evidence remain outstanding.

### Active next feature — assessment tournament

Assessment tournament software is integrated and source/automated/browser-verified; its delivered flow is documented in the `assessment-tournament` map. Remaining follow-up is trained-operator acceptance of neutral wording and real-session usability. Keep it separate from journey routing, diagnosis, consent inference, sales prompts and automatic service recommendations.

For each fix: reproduce or prove the branch → implement the smallest correction → verify that branch and its neighboring exits → update the corresponding atlas map and source references. Keep a separate change record for each fix. Do not claim deployment from local checks.
## CP-MOD-062 — Settings manager view ownership (implemented locally)

Moved Manage Settings navigation, export/import event handling, status messages and the Advanced Features export gate to `modules/settings-manager-view.js`. Backup schema validation and managed-storage replacement remain in `modules/settings-backup.js`; the app continues to provide screen navigation, localization and the current session unlock state. Import remains available while locked, export remains unavailable while locked, and cancellation/invalid-input paths preserve existing settings. Direct module interaction tests and atlas rebuild are required. No browser or device evidence is claimed; remote publication and integration remain approval-gated.
## CP-MOD-063 — Audio volume settings view ownership (implemented locally)

Moved the seven paired or single mixer volume-slider bindings into `modules/audio-volume-settings-view.js`. It retains the existing `chakra_` preference key construction, mirror synchronization, active voice/drone/bell/mantra gain changes, music transition previous-volume input, video gain and Visualization ambience gain. Audio graph ownership, voice effects, spatial modes, playback and the preview controls remain in their existing owners. Verify with direct slider contracts and the `sound-options` atlas map; no runtime performance gain is presumed from an eager module extraction.
## CP-MOD-064 — Audio effects settings view ownership (implemented locally)

Moved voice clarity/warmth/pace, voice and music echo selectors, spatial-mode selectors and voice-preset interactions to `modules/audio-effects-settings-view.js`. Existing storage keys, preset values, spatial normalization, mirrored control updates and audio APIs are unchanged. DSP graph implementation and hydration remain with their existing owners. Validate direct user-input paths and `sound-options` references; do not claim audio-quality or performance changes from the extraction.
## CP-MOD-065 — Journey preparation selection ownership (implemented locally)

Moved Box Breathing, Ho’oponopono, Dharana, Visualization, Body Scan, Guided Noting and Undo & Unlearn Lobby selection listeners to `modules/journey-preparation-selection.js`. The module owns inline option-row visibility for the five options panels, session selection flags for Box/Ho’oponopono, mutual-exclusion clearing and the established visibility/estimate refresh calls. Standalone eligibility, chakra validation and dispatch remain with journey routing. Keep the existing standalone and guided paths distinct in the atlas.
## CP-MOD-069 completed locally — paired audio mode controls

Extracted the paired Lobby/mixer No Frequency and No Mantra event handling and existing state/audio side effects to `modules/audio-mode-settings-view.js`. The `sound-options` map topology is unchanged; ownership references are refreshed. Direct tests cover binding, mirrored state, persistence, shutdown ordering and eligible ambience restart. No browser/device or performance claim is made.
## CP-MOD-070–072 completed locally — three small Lobby settings-view seams

- CP-MOD-070: Returning Journey and Video Introduction preference event handlers moved to `modules/journey-preference-settings-view.js`; roadmap behavior unchanged.
- CP-MOD-071: intention input state/localStorage synchronization moved to `modules/intention-settings-view.js`; journey-script/default selection unchanged.
- CP-MOD-072: chakra selection persistence, estimate/roadmap refresh, and active chip styling moved to `modules/chakra-selection-view.js`; selection validation/dispatch unchanged.
- Atlas source ownership references were updated for `journey-roadmap`, `standard`, and `modes`. Flow topology did not change. Automated tests only; browser/device and performance evidence are not claimed.
## CP-MOD-073–077 completed locally — five app-shell interaction owners

- CP-MOD-073 extended the existing screen-navigation owner with Settings/Experiment CTA bindings.
- CP-MOD-074 extracted Settings help modal open/focus/close behavior.
- CP-MOD-075 extracted brightness, Eyes Close and audio-filter controls.
- CP-MOD-076 extracted mixer open/close/focus behavior; Restart remains app-owned and uses the view's hide adapter.
- CP-MOD-077 extracted audio preview buttons and platform Media Session actions, without moving their playback engines.
- Updated startup, experiments, controls, restart, sound-options and visuals map source references. No flow topology changed; focused automated tests only. No browser/device or performance gain is claimed.

## CP-MOD-078–082 — bounded app-view and module-selection ownership (implemented locally)

Extract experiment duration/start UI, route the existing Lobby assessment CTA through screen navigation, extract session pause/stop controls and completion dismissal, and centralize selected-practice toggle-to-module mapping in the existing practice loader. Preserve experiment execution, assessment separation, lifecycle ownership, completion/handoff order, and selected-only lazy loading. These are organization/testability changes only. Focused automated checks passed; browser/device/performance evidence is not claimed.

## CP-MOD-083–087 — existing view-owner event bindings (implemented locally)

Move add-on duration estimate refresh and Visualization ambience preference binding into the preparation-selection owner; move Yoga setup persistence listeners and drone-duration radio selection into their existing settings owners; move Music Only/High Energy selection bindings into preparation selection. Keep Advanced Features gating, session-mode behavior, storage keys and callback order unchanged. Tests pass for the affected view contracts. The neighboring `test:drone-duration` is unrun past fixture loading because `docs/dot.json` is owner-managed and absent in this checkout. No browser, device, or performance claim.

## CP-MOD-088–097 — remaining bounded Lobby/settings event owners (implemented locally)

Move High Energy estimate refresh, primary duration sliders, Mood & Relaxation toggles/sliders, Yoga's Advanced Features event gate and Shot-type reset/refresh binding into their existing modules. Preserve mode precedence, validation/confirmation, suppression behavior, persistence keys and update ordering. Focused module and adjacent journey tests are the acceptance evidence; no browser/device or performance claims.

## CP-MOD-098–107 — language and mode-control event ownership (implemented locally)

- Move meditation-language, display-language and selected-voice preference changes to `locale-ui-renderer.js`; generated-intention localization and voice setup order are preserved.
- Move both voice-preview button bindings to `media-controls-view.js`.
- Move Corpse Pose master-toggle callback binding to `yoga-experience-settings.js`.
- Move Sleep's locked/unlocked branches and Shots' locked, No Frequency, confirmation-cancel and confirmed activation/exclusivity branches to `lobby-experience-visibility.js`.
- Leave master-toggle policy, Advanced Features unlock/password lifecycle and repertory URL handoff in `app.js`; no new eager modules or lazy-loading boundaries.
- Focused locale/media/Yoga/Lobby tests pass. Browser/device/performance evidence is not claimed; atlas source ownership and handoff were refreshed.

## CP-MOD-108–127 — existing-owner value and display policies (implemented locally)

- Move Mood & Relaxation gain/blur clamps, URL and intensity normalization, profile/mix selection and display formatting (8) into its existing settings owner.
- Move Shot duration defaults, drone-mode normalization, fixed drone-duration calculation, clock formatting and Sleep stage validation (7) into timing settings; move spatial-mode normalization (1) beside the audio effects settings.
- Move countdown SVG progress/hide rendering (2) into the existing countdown owner, conservative narration-duration estimation (1) into session estimates and visual-effect fallback normalization (1) into the visual engine.
- Preserve existing app adapters, policy values, units, validation and current eager/offline module delivery. No behavior/performance improvement is claimed.
- Relevant direct module tests pass; browser/device testing remains skipped. Atlas map count/topology is unchanged for this batch; ownership notes and handoff were refreshed.

## CP-MOD-149–151 — Piper voice setup ownership (implemented locally)

- Move locale-compatible voice selection policy, Piper voice-registry loading with browser fallback, and browser/Piper voice picker option rendering, refresh and silent discovery warm-up into `modules/piper-lifecycle.js`.
- Keep locale/default policy supplied by app adapters and preserve voice synthesis, event timing, classic-script startup and offline delivery.
- Focused Piper, Hindi and Russian contracts pass. No browser/device/performance evidence; no lazy-loading boundary changed.

## Release test harness refresh — implemented locally

- Replaced stale app-source slicing assertions for localized intention, audio-mode controls and completion handoff with direct behavior checks against their current module owners; repaired Advanced Features test boundaries after handler relocation.
- The remaining full-suite exceptions are limited to `test:content-safety` and `test:drone-duration`, which cannot load the absent owner-maintained `docs/dot.json` fixture. No unrelated project data was substituted.

## CP-MOD-128 — chakra-symbol image lifecycle ownership (implemented locally)

Move the selected symbol/deity/Yoga image load, stale-request guard, failed-image hiding and cached-image reveal into the existing visual owner. Keep image choices and all UI/journey sequencing unchanged. Direct visual contract tests pass; no new script/cache/lazy boundary or performance claim. Next: audit one cohesive app/controller owner seam rather than forcing a fixed-size extraction batch.

## CP-MOD-129–148 — 20 existing-owner helper extractions (implemented locally)

- Piper voice profile: ID/registry lookup, cadence bounds and settings, browser/Piper gender policy, locale matching and voice selection (10).
- Completion Earn-link timer lifecycle (3), voice-status view rendering (1), demo timing policy helpers (3), localized generated-intention refresh (2), and drone-duration summary rendering (1).
- Existing event ordering, output copy, audio/session policy, and offline/eager delivery remain unchanged. Focused direct contracts pass; this does not claim performance or device gains.

## CP-MOD-152 — Mood & Relaxation audio lifecycle ownership (implemented locally)

- Moved ambience spatial approach, manifest/local/custom URL decoding, custom-source rollback, seamless-loop start/stop, gain/blur automation and intensity application into `modules/audio-pleasure-ambience.js` behind the existing AudioEngine methods.
- Preserved state ownership, setting values, fade and automation timing, No Frequency guards, URL persistence/recovery, warnings and stop-time buffer cleanup. Added a direct lifecycle contract and kept the module eagerly available/offline cached.
- Update the `sound-options` ownership notes. No journey topology, sound-quality, startup or thermal change is claimed.

## Journey Skip + localized aura orientation (merged to production, PR #90)

- Add a global Skip current item control that is active only while a planned stage is running; Skip cancels that item’s audio/narration/visual work and resumes the remaining sequence, while Stop still ends the whole journey.
- Ensure first-time chakra orientation is itself skippable and that skipping it proceeds directly into the normal journey setup without transiently showing Arriving before orientation finishes.
- Use the responsive, gender-neutral aura scene with the active chakra symbol, translated name/location caption and Meditation-Language narration. English, Malayalam, Hindi, Russian and Tamil UI keys are supplied.
- Regression coverage: item-runner lifecycle, skip control event, newcomer orientation translation and atlas. PR #90 merged to `production` as `fa799c4` on 2026-09-29. Browser/device validation remains with the owner; it was not run or claimed.
